# CLASS DEFINITIONS #

class Student:
	def __init__(self, name = "Default", idnum = "Default"):
		self.name = name
		self.idnum = idnum
		
    # Set/get student name
	def setName(self, newName = ""): # Input: Takes a name string from user input
		self.name = newName
	# Get user ID
	def getName(self):
		return self.name	
    
    # Set user ID
	def setID(self, newID = ""): # Input: Takes a name string from user input
		self.idnum = newID
	# Get user ID
	def getID(self):
		return self.idnum
	
    # Outputs a greeting to check the returns for name and idnum work correctly
	def greeting(self):
		print("Thank you, " + self.getName() + ". You have registered with ID: " + self.getID())
		
    # Input: moduleCode, argument entered by the user
    # Prints a message letting the user know they were registered for the module    
	def register(self, moduleCode):
		print(self.name + " is now registered for " + moduleCode) 

