# PROCEDURAL CODE #

from student import Student

newStudent = Student() # Create a new Student object called newStudent		

userName = input("Please enter your full name: ") # Ask the user's input for their name and ID
userID = input("Please enter your student ID number: ")

newStudent.setName(userName) # Use class getter/setter to set user input to the newStudent object
newStudent.setID(userID)

newStudent.greeting() # Call the greeting function to check name/idnum set correctly

userModule = input("Please enter a module code to register: ") # Ask a user to input their module choice
newStudent.register(userModule) # Pass the module code to the register function